import Foundation

struct RecipeCost: Codable, Hashable {
    let item: String
    let count: Int
}

struct MaterialItem: Codable, Identifiable, Hashable {
    let id: String
    let name: String
    let rarity: String
    let usedFor: String
    let whereToFind: String
    let maps: [String]
    let notes: String
}

struct Blueprint: Codable, Identifiable, Hashable {
    let id: String
    let name: String
    let type: String
    let station: String
    let recipe: [RecipeCost]
    let howToGet: String
    let maps: [String]
}

struct Enemy: Codable, Identifiable, Hashable {
    let id: String
    let name: String
    let threat: String
    let weakPoints: String
    let drops: [String]
    let whereFound: String
    let tips: String
}

struct GameMap: Codable, Identifiable, Hashable {
    let id: String
    let name: String
    let description: String
    let lootNotes: [String]
    let bestFor: [String]
}

struct WorkshopLevel: Codable, Hashable {
    let level: Int
    let costs: [RecipeCost]
}

struct WorkshopStation: Codable, Identifiable, Hashable {
    let id: String
    let name: String
    let crafts: String
    let levels: [WorkshopLevel]
}

struct GuideData: Codable {
    let materials: [MaterialItem]
    let blueprints: [Blueprint]
    let enemies: [Enemy]
    let maps: [GameMap]
    let workshop: [WorkshopStation]
    let about: String

    static let empty = GuideData(materials: [], blueprints: [], enemies: [], maps: [], workshop: [], about: "")
}

/// One row in unified search results / category lists.
enum GuideCategory: String, CaseIterable, Identifiable {
    case materials = "Materials"
    case blueprints = "Blueprints"
    case enemies = "Enemies"
    case maps = "Maps"
    case workshop = "Workshop"
    var id: String { rawValue }
    var icon: String {
        switch self {
        case .materials: return "shippingbox.fill"
        case .blueprints: return "doc.richtext.fill"
        case .enemies: return "cpu.fill"
        case .maps: return "map.fill"
        case .workshop: return "hammer.fill"
        }
    }
}

struct GuideHit: Identifiable, Hashable {
    let id: String          // prefixed entry id, unique across categories
    let entryID: String     // raw id inside its category
    let title: String
    let subtitle: String
    let category: GuideCategory
}
