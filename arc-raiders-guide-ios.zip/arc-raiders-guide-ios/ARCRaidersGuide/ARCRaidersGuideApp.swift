import SwiftUI

@main
struct ARCRaidersGuideApp: App {
    @StateObject private var guide = GuideStore()
    @StateObject private var run = RunStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(guide)
                .environmentObject(run)
                .tint(.orange)
        }
    }
}
