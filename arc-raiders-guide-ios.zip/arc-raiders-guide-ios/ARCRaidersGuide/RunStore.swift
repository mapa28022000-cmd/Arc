import Foundation

/// One pinned item in the "My Run" tracker.
struct RunPin: Codable, Identifiable, Equatable {
    var id: String          // the GuideHit id, e.g. "m:mat-11"
    var title: String
    var category: String
    var have: Int
    var need: Int
}

/// Persists pins to UserDefaults as JSON so the run list survives relaunch.
@MainActor
final class RunStore: ObservableObject {
    @Published var pins: [RunPin] = [] {
        didSet { save() }
    }

    private let key = "myRunPins.v1"
    private var isLoading = false

    init() {
        isLoading = true
        if let raw = UserDefaults.standard.data(forKey: key),
           let decoded = try? JSONDecoder().decode([RunPin].self, from: raw) {
            pins = decoded
        }
        isLoading = false
    }

    private func save() {
        guard !isLoading else { return }
        if let raw = try? JSONEncoder().encode(pins) {
            UserDefaults.standard.set(raw, forKey: key)
        }
    }

    func isPinned(_ hitID: String) -> Bool { pins.contains { $0.id == hitID } }

    func toggle(hit: GuideHit, defaultNeed: Int = 1) {
        if let idx = pins.firstIndex(where: { $0.id == hit.id }) {
            pins.remove(at: idx)
        } else {
            pins.append(RunPin(id: hit.id, title: hit.title, category: hit.category.rawValue, have: 0, need: max(1, defaultNeed)))
        }
    }

    func addMaterial(_ material: MaterialItem, count: Int) {
        let hitID = "m:" + material.id
        if let idx = pins.firstIndex(where: { $0.id == hitID }) {
            pins[idx].need += count
        } else {
            pins.append(RunPin(id: hitID, title: material.name, category: GuideCategory.materials.rawValue, have: 0, need: max(1, count)))
        }
    }

    func remove(at offsets: IndexSet) {
        pins.remove(atOffsets: offsets)
    }

    func clearCompleted() {
        pins.removeAll { $0.have >= $0.need }
    }

    func clearAll() {
        pins.removeAll()
    }
}
