import SwiftUI

struct ContentView: View {
    @EnvironmentObject var guide: GuideStore

    var body: some View {
        Group {
            if let error = guide.loadError {
                ContentUnavailableView("Guide data problem", systemImage: "exclamationmark.triangle", description: Text(error))
            } else {
                TabView {
                    GuideView()
                        .tabItem { Label("Guide", systemImage: "magnifyingglass") }
                    MaterialsView()
                        .tabItem { Label("Materials", systemImage: "shippingbox.fill") }
                    BlueprintsView()
                        .tabItem { Label("Blueprints", systemImage: "doc.richtext.fill") }
                    MyRunView()
                        .tabItem { Label("My Run", systemImage: "checklist") }
                }
            }
        }
    }
}

/// Row used by search results and category lists.
struct HitRow: View {
    let hit: GuideHit

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: hit.category.icon)
                .foregroundStyle(.orange)
                .frame(width: 28)
            VStack(alignment: .leading, spacing: 2) {
                Text(hit.title).font(.headline)
                Text(hit.subtitle)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
            }
        }
        .padding(.vertical, 2)
    }
}

/// Navigates a unified hit to its typed detail screen.
struct HitDestination: View {
    @EnvironmentObject var guide: GuideStore
    let hit: GuideHit

    var body: some View {
        switch hit.category {
        case .materials:
            if let item = guide.material(id: hit.entryID) { MaterialDetailView(material: item) }
        case .blueprints:
            if let item = guide.blueprint(id: hit.entryID) { BlueprintDetailView(blueprint: item) }
        case .enemies:
            if let item = guide.enemy(id: hit.entryID) { EnemyDetailView(enemy: item) }
        case .maps:
            if let item = guide.gameMap(id: hit.entryID) { MapDetailView(map: item) }
        case .workshop:
            if let item = guide.station(id: hit.entryID) { WorkshopDetailView(station: item) }
        }
    }
}

/// Pin / unpin button shown on detail screens.
struct PinButton: View {
    @EnvironmentObject var run: RunStore
    let hit: GuideHit
    var defaultNeed: Int = 1

    var body: some View {
        Button {
            run.toggle(hit: hit, defaultNeed: defaultNeed)
        } label: {
            Label(run.isPinned(hit.id) ? "Pinned to My Run" : "Pin to My Run",
                  systemImage: run.isPinned(hit.id) ? "pin.fill" : "pin")
        }
        .buttonStyle(.borderedProminent)
    }
}
