import SwiftUI

/// Search / Guide tab: instant search across every category, with category chips.
struct GuideView: View {
    @EnvironmentObject var guide: GuideStore
    @State private var query = ""
    @State private var category: GuideCategory?

    private var results: [GuideHit] {
        guide.search(query, category: category)
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                Picker("Category", selection: $category) {
                    Text("All").tag(GuideCategory?.none)
                    ForEach(GuideCategory.allCases) { c in
                        Text(c.rawValue).tag(GuideCategory?.some(c))
                    }
                }
                .pickerStyle(.segmented)
                .padding()

                List(results) { hit in
                    NavigationLink(value: hit) {
                        HitRow(hit: hit)
                    }
                }
                .listStyle(.plain)
                .overlay {
                    if results.isEmpty {
                        ContentUnavailableView.search(text: query)
                    }
                }
            }
            .navigationTitle("ARC Raiders Guide")
            .navigationDestination(for: GuideHit.self) { hit in
                HitDestination(hit: hit)
            }
            .searchable(text: $query, prompt: "Try \"moss\", \"Sentinel\", \"hospital\"...")
            .toolbar {
                ToolbarItem(placement: .bottomBar) {
                    Text(guide.data.about)
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                        .lineLimit(3)
                }
            }
        }
    }
}
