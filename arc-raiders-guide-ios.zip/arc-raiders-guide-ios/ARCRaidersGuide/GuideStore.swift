import Foundation

/// Loads the bundled guide.json once at launch. Fully offline - no networking.
@MainActor
final class GuideStore: ObservableObject {
    @Published private(set) var data: GuideData = .empty
    @Published private(set) var loadError: String?

    init() {
        load()
    }

    func load() {
        guard let url = Bundle.main.url(forResource: "guide", withExtension: "json") else {
            loadError = "guide.json is missing from the app bundle."
            return
        }
        do {
            let raw = try Data(contentsOf: url)
            data = try JSONDecoder().decode(GuideData.self, from: raw)
        } catch {
            loadError = "Could not read guide data: \(error.localizedDescription)"
        }
    }

    // MARK: - Lookups

    func material(id: String) -> MaterialItem? { data.materials.first { $0.id == id } }
    func blueprint(id: String) -> Blueprint? { data.blueprints.first { $0.id == id } }
    func enemy(id: String) -> Enemy? { data.enemies.first { $0.id == id } }
    func gameMap(id: String) -> GameMap? { data.maps.first { $0.id == id } }
    func station(id: String) -> WorkshopStation? { data.workshop.first { $0.id == id } }

    func material(named name: String) -> MaterialItem? {
        data.materials.first { $0.name.caseInsensitiveCompare(name) == .orderedSame }
    }

    // MARK: - Unified search

    func allHits() -> [GuideHit] {
        var hits: [GuideHit] = []
        hits += data.materials.map { GuideHit(id: "m:" + $0.id, entryID: $0.id, title: $0.name, subtitle: $0.usedFor, category: .materials) }
        hits += data.blueprints.map { GuideHit(id: "b:" + $0.id, entryID: $0.id, title: $0.name, subtitle: $0.type + " · " + $0.station, category: .blueprints) }
        hits += data.enemies.map { GuideHit(id: "e:" + $0.id, entryID: $0.id, title: $0.name, subtitle: "Threat: " + $0.threat, category: .enemies) }
        hits += data.maps.map { GuideHit(id: "map:" + $0.id, entryID: $0.id, title: $0.name, subtitle: $0.description, category: .maps) }
        hits += data.workshop.map { GuideHit(id: "w:" + $0.id, entryID: $0.id, title: $0.name, subtitle: $0.crafts, category: .workshop) }
        return hits
    }

    func search(_ query: String, category: GuideCategory?) -> [GuideHit] {
        let q = query.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        return allHits().filter { hit in
            if let category, hit.category != category { return false }
            if q.isEmpty { return true }
            if hit.title.lowercased().contains(q) || hit.subtitle.lowercased().contains(q) { return true }
            // Also match against body fields so "firing core", "hospital" or "defibrillator" find the right rows.
            switch hit.category {
            case .materials:
                guard let m = material(id: hit.entryID) else { return false }
                return m.whereToFind.lowercased().contains(q) || m.notes.lowercased().contains(q) || m.maps.contains { $0.lowercased().contains(q) }
            case .blueprints:
                guard let b = blueprint(id: hit.entryID) else { return false }
                return b.howToGet.lowercased().contains(q) || b.recipe.contains { $0.item.lowercased().contains(q) }
            case .enemies:
                guard let e = enemy(id: hit.entryID) else { return false }
                return e.drops.contains { $0.lowercased().contains(q) } || e.weakPoints.lowercased().contains(q)
            case .maps:
                guard let m = gameMap(id: hit.entryID) else { return false }
                return m.bestFor.contains { $0.lowercased().contains(q) } || m.lootNotes.contains { $0.lowercased().contains(q) }
            case .workshop:
                guard let w = station(id: hit.entryID) else { return false }
                return w.levels.flatMap { $0.costs }.contains { $0.item.lowercased().contains(q) }
            }
        }
    }
}
