import SwiftUI

/// "My Run" tracker: pinned items with have / need counters. Persisted by RunStore.
struct MyRunView: View {
    @EnvironmentObject var run: RunStore

    var body: some View {
        NavigationStack {
            Group {
                if run.pins.isEmpty {
                    ContentUnavailableView {
                        Label("Nothing pinned yet", systemImage: "pin.slash")
                    } description: {
                        Text("Open any material, blueprint or enemy and tap \"Pin to My Run\", or tap + on a blueprint recipe to build your farm list before you drop in.")
                    }
                } else {
                    List {
                        ForEach($run.pins) { $pin in
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(pin.title).font(.headline)
                                        Text(pin.category).font(.caption).foregroundStyle(.secondary)
                                    }
                                    Spacer()
                                    if pin.have >= pin.need {
                                        Label("Done", systemImage: "checkmark.circle.fill")
                                            .foregroundStyle(.green)
                                            .font(.subheadline)
                                    }
                                }
                                HStack {
                                    Stepper("Have: \(pin.have)", value: $pin.have, in: 0...999)
                                    Stepper("Need: \(pin.need)", value: $pin.need, in: 1...999)
                                }
                                .font(.subheadline)
                                ProgressView(value: Double(min(pin.have, pin.need)), total: Double(pin.need))
                                    .tint(.orange)
                            }
                            .padding(.vertical, 2)
                        }
                        .onDelete { run.remove(at: $0) }
                    }
                    .listStyle(.plain)
                }
            }
            .navigationTitle("My Run")
            .toolbar {
                if !run.pins.isEmpty {
                    Menu {
                        Button("Clear completed", systemImage: "checkmark.circle") { run.clearCompleted() }
                        Button("Clear all", systemImage: "trash", role: .destructive) { run.clearAll() }
                    } label: {
                        Image(systemName: "ellipsis.circle")
                    }
                }
            }
        }
    }
}
