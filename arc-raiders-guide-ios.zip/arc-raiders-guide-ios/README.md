# ARC Raiders Guide — iPhone App

A personal, fully-offline guide to **ARC Raiders** for Miguel's iPhone. No accounts, no internet, no ads, no cost to run.

**What's inside**

- **Guide tab** — instant search across everything. Try "moss", "Sentinel", "hospital" or "defibrillator".
- **Materials tab** — 59 materials: what they're for, where to farm them, and which maps.
- **Blueprints tab** — 21 blueprints (Anvil, Bobcat, Bettina, Equalizer, Jupiter, Hullcracker, Aphelion…) with full crafting recipes and how to get each blueprint.
- **Enemies, maps & workshop** — in search: every major ARC enemy with weak points and drops, all 6 maps with loot notes, and every Workshop station's upgrade costs.
- **My Run tab** — pin what you're farming, set how many you *need* and tap up how many you *have*. Blueprint recipes can add their ingredients straight to your run. Your list is saved on the phone and survives closing the app.

Data lives in `ARCRaidersGuide/guide.json`, compiled from public guides in October 2026. Game patches can change recipes — if the game and the app disagree, believe the game.

---

## How to get it on your iPhone — 3 routes

You do **not** need to pay Apple anything for personal use. Pick one:

### Route 1 — Xcode on a Mac (free, but the app expires every 7 days)

Needs: any Mac, Xcode (free from the Mac App Store), your normal Apple ID.

1. Open `ARCRaidersGuide.xcodeproj` in Xcode.
2. Click the project name (top left) → target **ARCRaidersGuide** → **Signing & Capabilities** → tick **Automatically manage signing** and pick your Apple ID under *Team* (add it in Xcode → Settings → Accounts if needed).
3. Plug in your iPhone, pick it as the run destination, press **▶ Run**.
4. On the iPhone: Settings → General → VPN & Device Management → trust your developer profile.
5. **The catch:** with a free Apple ID the app stops opening after **7 days**. To refresh it, plug in and press Run in Xcode again. Your My Run data is kept as long as you don't delete the app.

### Route 2 — SideStore / AltStore (free, auto-refreshes itself) ← recommended if you have no Mac handy

Needs: the unsigned `.ipa` file. Build it on a cloud Mac: create a free Codemagic account, add this project, and run the included `codemagic.yaml` workflow ("ARC Raiders Guide - Unsigned IPA"). Download the resulting `ARCRaidersGuide-unsigned.ipa`.

1. Install **SideStore** (sidestore.io) or **AltStore** (altstore.io) on your iPhone, following their setup guide (a one-time setup with a computer).
2. Open the app, add the `.ipa`, and sign it with your free Apple ID when asked.
3. SideStore/AltStore **refresh the app automatically in the background** before the 7-day free-signing limit runs out, as long as your phone is on Wi-Fi regularly.
4. Free Apple IDs can have only a few sideloaded apps active at once — this counts as one.

### Route 3 — Apple Developer Program ($99/year, no expiry hassle)

Needs: a paid Apple Developer account.

1. Enroll at developer.apple.com ($99/year).
2. In Xcode, sign the app with your paid team (same steps as Route 1), **or** upload the build to **TestFlight** and install it from the TestFlight app.
3. Apps installed this way last **1 year** instead of 7 days, and TestFlight installs don't need a cable.

---

## Project layout

```
ARCRaidersGuide.xcodeproj   <- open this in Xcode
ARCRaidersGuide/
  ARCRaidersGuideApp.swift  <- app entry
  Models.swift              <- data models
  GuideStore.swift          <- loads guide.json, unified search
  RunStore.swift            <- My Run pins, saved in UserDefaults
  ContentView.swift         <- tab bar + shared rows/buttons
  GuideView.swift           <- search tab
  MaterialsView.swift       <- Materials + Blueprints tabs
  DetailViews.swift         <- detail screens for every category
  MyRunView.swift           <- My Run tracker
  guide.json                <- all guide data (edit this to update the guide)
  Assets.xcassets           <- app icon + accent color
codemagic.yaml              <- cloud build for the unsigned IPA (Route 2)
BUILD_NOTES.md              <- what was built and how it was checked
```
