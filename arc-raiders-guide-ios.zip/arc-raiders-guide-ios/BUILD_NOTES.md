# BUILD NOTES — ARC Raiders Guide (iOS)

Built 2026-10-27 for Miguel, personal use only.

## What was created

A complete, native SwiftUI Xcode project (no third-party dependencies, no API keys, fully offline):

- `ARCRaidersGuide.xcodeproj` — bundle id `com.miguel.arcraidersguide`, iOS 17.0 deployment target, Swift 5, generated Info.plist, AppIcon + AccentColor asset catalogs.
- 9 Swift sources: app entry, models, `GuideStore` (loads bundled JSON, unified cross-category search), `RunStore` (My Run pins persisted as JSON in UserDefaults — survives relaunch), tab bar (Guide/Search, Materials, Blueprints, My Run), list views, and detail screens for materials, blueprints, enemies, maps and workshop stations. Blueprint detail screens can add each recipe ingredient to My Run with the required count.
- `ARCRaidersGuide/guide.json` — all content bundled locally. Sources: public ARC Raiders guides (PCGamesN, GamesFuze, AllThings, BlazingBoost, ImmortalBoost, NerdsChalk and similar, consulted Oct 2026). Where a source disagreed (e.g. Anvil Simple Gun Parts x5 vs x6), the majority value was used; where an exact spawn is not reliably documented (e.g. Moss), the entry says "general farm area" instead of inventing a spot. An in-app disclaimer notes patches can change recipes.
- `ARCRaidersGuide/Assets.xcassets/AppIcon.appiconset/AppIcon-1024.png` — simple generated placeholder icon (dark background, orange/white chevrons). Swap in real art any time by replacing that one PNG.
- `codemagic.yaml` — workflow `arc-raiders-guide-unsigned`: builds Release for generic iOS with signing disabled on a cloud Mac and packages an unsigned `.ipa` (Payload zip) for SideStore/AltStore signing.
- `README.md` — app overview + the three install routes in plain language: (1) Xcode + free Apple ID (7-day expiry, re-run to refresh), (2) SideStore/AltStore with the unsigned IPA + free Apple ID auto-refresh, (3) Apple Developer Program $99/yr (1-year installs / TestFlight).

## Dataset size

| Category | Count |
| --- | --- |
| Materials | 59 |
| Blueprints | 21 |
| Enemies | 16 |
| Maps | 6 |
| Workshop stations | 7 (with per-level costs) |
| **Total guide entries** | **109** |

## Validation performed on this Linux VM

- ✅ `guide.json` parses with Python `json`; every entry's fields exactly match the Swift `Codable` model fields; all ids unique; all recipe/workshop costs are `{item, count:int}`.
- ✅ All 23 distinct blueprint recipe ingredients resolve to a material entry (so every ingredient shows the + add-to-My-Run button).
- ✅ Every file referenced in `project.pbxproj` exists on disk at the referenced path, and the bundle id in the project is `com.miguel.arcraidersguide`.
- ✅ Rough Swift syntax sanity: balanced braces/parens/brackets in all 9 Swift files (no Swift compiler exists on this VM).
- ✅ App icon is a valid 1024×1024 PNG; `codemagic.yaml` parses as valid YAML.

## NOT validated here (needs a Mac / cloud build)

- ❌ Actual compilation with Xcode / `xcodebuild` — there is no macOS or Swift toolchain on this Linux VM, so Swift compile errors (if any) and asset-catalog compilation can only be confirmed on the first Mac or Codemagic build.
- ❌ Runtime behavior on a device/simulator (tab navigation, persistence across relaunch) — code follows standard SwiftUI patterns but was not executed.
- ❌ The Codemagic workflow has not been run; it is written from the standard unsigned-build recipe.
