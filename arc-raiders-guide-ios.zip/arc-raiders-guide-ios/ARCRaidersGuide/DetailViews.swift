import SwiftUI

private struct SectionTitle: View {
    let text: String
    var body: some View {
        Text(text).font(.headline).padding(.top, 8)
    }
}

struct MaterialDetailView: View {
    @EnvironmentObject var guide: GuideStore
    let material: MaterialItem

    var body: some View {
        List {
            Section {
                LabeledContent("Rarity", value: material.rarity)
                LabeledContent("Used for", value: material.usedFor)
            }
            Section("Where to find it") {
                Text(material.whereToFind)
                ForEach(material.maps, id: \.self) { map in
                    Label(map, systemImage: "map")
                }
            }
            Section("Notes") {
                Text(material.notes)
            }
            Section {
                PinButton(hit: GuideHit(id: "m:" + material.id, entryID: material.id,
                                         title: material.name, subtitle: material.usedFor, category: .materials))
            }
        }
        .navigationTitle(material.name)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct BlueprintDetailView: View {
    @EnvironmentObject var guide: GuideStore
    @EnvironmentObject var run: RunStore
    let blueprint: Blueprint

    var body: some View {
        List {
            Section {
                LabeledContent("Type", value: blueprint.type)
                LabeledContent("Crafted at", value: blueprint.station)
            }
            Section("How to get the blueprint") {
                Text(blueprint.howToGet)
                ForEach(blueprint.maps, id: \.self) { map in
                    Label(map, systemImage: "map")
                }
            }
            Section("Recipe") {
                ForEach(blueprint.recipe, id: \.item) { part in
                    HStack {
                        Text(part.item)
                        Spacer()
                        Text("x\(part.count)").foregroundStyle(.secondary)
                        if let mat = guide.material(named: part.item) {
                            Button {
                                run.addMaterial(mat, count: part.count)
                            } label: {
                                Image(systemName: "plus.circle")
                            }
                            .buttonStyle(.borderless)
                            .accessibilityLabel("Add \(part.item) to My Run")
                        }
                    }
                }
                Text("Tap + to add an ingredient to My Run with the amount you need.")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Section {
                PinButton(hit: GuideHit(id: "b:" + blueprint.id, entryID: blueprint.id,
                                         title: blueprint.name, subtitle: blueprint.type, category: .blueprints))
            }
        }
        .navigationTitle(blueprint.name)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct EnemyDetailView: View {
    let enemy: Enemy

    var body: some View {
        List {
            Section {
                LabeledContent("Threat", value: enemy.threat)
                LabeledContent("Found", value: enemy.whereFound)
            }
            Section("Weak points") {
                Text(enemy.weakPoints)
            }
            Section("Drops") {
                ForEach(enemy.drops, id: \.self) { drop in
                    Label(drop, systemImage: "shippingbox")
                }
            }
            Section("Tips") {
                Text(enemy.tips)
            }
            Section {
                PinButton(hit: GuideHit(id: "e:" + enemy.id, entryID: enemy.id,
                                         title: enemy.name, subtitle: "Threat: " + enemy.threat, category: .enemies))
            }
        }
        .navigationTitle(enemy.name)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct MapDetailView: View {
    let map: GameMap

    var body: some View {
        List {
            Section {
                Text(map.description)
            }
            Section("Loot notes") {
                ForEach(map.lootNotes, id: \.self) { note in
                    Text("• " + note)
                }
            }
            Section("Best for farming") {
                ForEach(map.bestFor, id: \.self) { item in
                    Label(item, systemImage: "shippingbox")
                }
            }
        }
        .navigationTitle(map.name)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct WorkshopDetailView: View {
    let station: WorkshopStation

    var body: some View {
        List {
            Section {
                Text(station.crafts)
            }
            ForEach(station.levels, id: \.level) { level in
                Section("Level \(level.level)") {
                    if level.costs.isEmpty {
                        Text(level.level == 1 ? "Free / starting station" : "No materials required")
                            .foregroundStyle(.secondary)
                    } else {
                        ForEach(level.costs, id: \.item) { c in
                            HStack {
                                Text(c.item)
                                Spacer()
                                Text("x\(c.count)").foregroundStyle(.secondary)
                            }
                        }
                    }
                }
            }
        }
        .navigationTitle(station.name)
        .navigationBarTitleDisplayMode(.inline)
    }
}
