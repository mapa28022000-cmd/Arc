import SwiftUI

struct MaterialsView: View {
    @EnvironmentObject var guide: GuideStore
    @State private var query = ""

    private var filtered: [MaterialItem] {
        guide.data.materials.filter {
            query.isEmpty || $0.name.localizedCaseInsensitiveContains(query) || $0.usedFor.localizedCaseInsensitiveContains(query)
        }
    }

    var body: some View {
        NavigationStack {
            List(filtered) { material in
                NavigationLink(value: material) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(material.name).font(.headline)
                        Text(material.usedFor).font(.subheadline).foregroundStyle(.secondary).lineLimit(1)
                    }
                }
            }
            .listStyle(.plain)
            .navigationTitle("Materials")
            .navigationDestination(for: MaterialItem.self) { material in
                MaterialDetailView(material: material)
            }
            .searchable(text: $query, prompt: "Filter materials")
        }
    }
}

struct BlueprintsView: View {
    @EnvironmentObject var guide: GuideStore
    @State private var query = ""

    private var filtered: [Blueprint] {
        guide.data.blueprints.filter {
            query.isEmpty || $0.name.localizedCaseInsensitiveContains(query) || $0.type.localizedCaseInsensitiveContains(query)
        }
    }

    var body: some View {
        NavigationStack {
            List(filtered) { blueprint in
                NavigationLink(value: blueprint) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(blueprint.name).font(.headline)
                        Text(blueprint.type + " · " + blueprint.station)
                            .font(.subheadline).foregroundStyle(.secondary).lineLimit(1)
                    }
                }
            }
            .listStyle(.plain)
            .navigationTitle("Blueprints")
            .navigationDestination(for: Blueprint.self) { blueprint in
                BlueprintDetailView(blueprint: blueprint)
            }
            .searchable(text: $query, prompt: "Filter blueprints")
        }
    }
}
